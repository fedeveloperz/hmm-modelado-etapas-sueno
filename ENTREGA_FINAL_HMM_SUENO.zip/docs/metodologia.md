# Marco Metodológico y Protocolo Experimental

Este documento describe la metodología experimental, el marco didáctico, la definición operacional de variables y el protocolo de reproducibilidad del proyecto **Modelado de las Etapas del Sueño Mediante Cadenas Ocultas de Markov y Semi-Markovianas**.

---

## 1. Marco Didáctico: USA $\to$ MODIFICA $\to$ CREA

El proyecto sigue una progresión metodológica estructurada en tres fases iterativas:

```mermaid
flowchart LR
    A["Fase 1: USA<br/>(HMM Base)"] --> B["Fase 2: MODIFICA<br/>(HMM Fragmentado)"]
    B --> C["Fase 3: CREA<br/>(HSMM Duraciones Explícitas)"]
    C --> D["Validación Inferencial<br/>(Monte Carlo M=100)"]
    D --> E["Consolidación Académica<br/>(Artículo IEEE + LaTeX)"]
```

### 1.1 Fase USA (Modelo HMM Original)
* **Objetivo:** Comprender la mecánica estocástica de un Modelo Oculto de Markov discreto estándar aplicado al sueño.
* **Procedimiento:** Se implementa el script `src/hmm_sueno.py` a partir de las matrices $A$, $B$ y $\pi$ hipotéticas iniciales. Se ejecuta con semilla determinista (`SEED = 42`) para un horizonte de 480 épocas (4 horas). Se aplica el algoritmo de Viterbi para evaluar la inferencia del estado oculto a partir de las observaciones fisiológicas simuladas.
* **Archivos asociados:** `src/hmm_sueno.py`, `resultados/csv/secuencia_simulada.csv`, `resultados/csv/metricas_etapas.csv`.

### 1.2 Fase MODIFICA (Simulación de Sueño Fragmentado)
* **Objetivo:** Analizar el impacto de una alteración patológica específica sobre la arquitectura del sueño sin modificar el espacio de estados ni las emisiones.
* **Procedimiento:** Se implementa `src/hmm_sueno_fragmentado.py`. Se incrementan selectivamente las probabilidades de transición directa hacia el estado Despierto desde Sueño Ligero ($0.10 \to 0.30$), Sueño Profundo ($0.05 \to 0.20$) y REM ($0.10 \to 0.25$). Se recalcula la matriz de transición normalizando proporcionalmente las probabilidades restantes por fila para satisfacer $\sum_j A_{ij} = 1.0$. Se ejecutan simulaciones comparativas bajo la misma semilla (`SEED = 42`).
* **Archivos asociados:** `src/hmm_sueno_fragmentado.py`, `resultados/csv/comparacion_metricas.csv`, `resultados/figuras/hipnograma_comparativo.png`.

### 1.3 Fase CREA (Modelo Semi-Markoviano HSMM)
* **Objetivo:** Superar la limitación matemática intrínseca del HMM tradicional (la distribución geométrica de permanencia temporal) mediante la formulación de duraciones explícitas de estado.
* **Procedimiento:** Se implementa `src/hmm_semimarkov.py`. Se desacopla la transición de la permanencia: se construye una cadena de Markov embebida con diagonal nula ($A_{ii} = 0$) y se asigna a cada estado una distribución uniforme discreta de duración acotada por umbrales mínimos y máximos fisiológicamente plausibles. Se decodifica la secuencia mediante un algoritmo de Viterbi segmentario optimizado con sumas de prefijo.
* **Archivos asociados:** `src/hmm_semimarkov.py`, `resultados/csv/comparacion_tres_modelos.csv`, `resultados/figuras/hipnograma_tres_modelos.png`.

---

## 2. Definición Operacional de Variables y Métricas

En las simulaciones computacionales del repositorio, el registro comprende $T = 480$ épocas/pasos discretos. En el código fuente Python, cada paso se computa nominalmente con $\Delta t = 1.0\text{ min}$ (equivalente a 480 minutos u 8 horas de registro continuo). En la interpretación comparativa con los criterios clínicos AASM (épocas de 30 segundos, $\Delta t = 0.5\text{ min}$), equivaldría a 240 minutos o 4 horas. Las fórmulas operacionales son:

1. **Tiempo Total de Registro (TRT - Total Recording Time):**
   $$\mathrm{TRT} = T \cdot \Delta t = 480 \cdot 1.0\text{ min} = 480.0\text{ minutos (8.0 horas)}$$
   *(o $240.0\text{ min}$ bajo el criterio de épocas de 30 s).*

2. **Tiempo Total de Sueño (TST - Total Sleep Time):**
   Suma de la duración de todas las épocas clasificadas en cualquier estado de sueño (Ligero, Profundo o REM), excluyendo vigilia:
   $$\mathrm{TST} = \sum_{t=1}^T \mathbb{I}(q_t \neq \text{Despierto}) \cdot \Delta t$$

3. **Eficiencia de Sueño (SE - Sleep Efficiency):**
   Porcentaje del tiempo de registro que el sujeto permanece dormido:
   $$\mathrm{SE} = \left( \frac{\mathrm{TST}}{\mathrm{TRT}} \right) \cdot 100\%$$

4. **Latencia de Inicio de Sueño (SOL - Sleep Onset Latency):**
   Tiempo transcurrido desde el inicio de la simulación ($t = 1$) hasta la aparición de la primera época de sueño:
   $$\mathrm{SOL} = (\min \{t : q_t \neq \text{Despierto}\} - 1) \cdot \Delta t$$

5. **Número de Despertares (Awakenings):**
   Conteo de eventos en los cuales el sistema transiciona desde un estado de sueño hacia el estado Despierto:
   $$\text{Despertares} = \sum_{t=2}^T \mathbb{I}(q_{t-1} \neq \text{Despierto} \land q_t = \text{Despierto})$$

6. **Ciclos de Sueño REM (Regla Operacional):**
   En polisomnografía clínica, un ciclo de sueño comprende típicamente una fase no-REM seguida de un episodio REM, con una periodicidad ultradiana de 90 a 120 minutos. En las simulaciones se define operacionalmente como cada entrada independiente a un bloque de estado REM precedido por un estado no-REM.

7. **Exactitud de Decodificación Global (Viterbi Accuracy):**
   Concordancia época a época entre la secuencia latente real $Q$ y la secuencia decodificada $\hat{Q}$:
   $$\text{Exactitud} = \left( \frac{1}{T} \sum_{t=1}^T \mathbb{I}(q_t = \hat{q}_t) \right) \cdot 100\%$$

---

## 3. Protocolo de Reproducibilidad y Diseño Monte Carlo

### 3.1 Control Pseudoaleatorio
Para garantizar reproducibilidad absoluta en cualquier arquitectura de hardware y sistema operativo:
* Se emplea el generador de números aleatorios moderno de NumPy: `np.random.default_rng(seed)`.
* Para corridas canónicas individuales, se utiliza de forma estricta: `SEED = 42`.
* El código no utiliza números aleatorios no controlados ni variables de entorno no declaradas.

### 3.2 Protocolo de Inferencia Estadística Monte Carlo
Para validar que las diferencias observadas entre modelos no constituyen artefactos atribuibles a una semilla particular, se implementó `src/analisis_estadistico_montecarlo.py`:
* **Número de réplicas independientes:** $M = 100$ ejecuciones completas por modelo.
* **Rango de semillas:** Enteros consecutivos $s \in [1000, 1099]$.
* **Métricas evaluadas:** TST, SE, SOL, Despertares, Ciclos REM y Exactitud de Viterbi.
* **Estadísticos calculados:** Media ($\bar{X}$), Desviación Estándar ($s$), Mínimo, Máximo y límites del Intervalo de Confianza del 95% basado en la distribución $t$-Student con $M-1 = 99$ grados de libertad ($t_{0.975, 99} = 1.9842$).
* **Almacenamiento:** Los resultados individuales se registran en `resultados/csv/corridas_montecarlo_tres_modelos.csv` (300 filas) y los estadísticos consolidados en `resultados/csv/estadisticas_montecarlo_tres_modelos.csv` (18 filas).

---

## 4. Trazabilidad y Control de Calidad Académico

1. **Bitácora de Decisiones Humanas (`materiales/bitacora.md`):**
   Cada propuesta analítica, ajuste de código y modificación de parámetros se documenta explícitamente distinguiendo:
   * Sugerencia de la inteligencia artificial.
   * Verificación empírica en el código y datos.
   * Decisión humana final y justificación metodológica.

2. **Diferenciación Estricta de Datos Sintéticos:**
   En todo momento se evita catalogar las simulaciones como registros clínicos reales de pacientes. Se discuten explícitamente las limitaciones de representatividad frente a la polisomnografía médica real.
