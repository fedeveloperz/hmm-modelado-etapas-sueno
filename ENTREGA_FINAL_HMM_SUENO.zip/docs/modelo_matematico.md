# Especificación Matemática Formal: Modelos Ocultos de Markov Aplicados al Sueño

Este documento presenta la formulación matemática rigurosa, probabilística y algorítmica de los tres modelos implementados en el proyecto: el **Modelo Oculto de Markov Estándar (HMM Base)**, el **HMM de Sueño Fragmentado** y el **Modelo Oculto Semi-Markoviano (HSMM)** con duraciones explícitas de permanencia.

---

## 1. Definición Formal de un Modelo Oculto de Markov (HMM)

Un Modelo Oculto de Markov discreto en tiempo y espacio de estados se define formalmente mediante la tupla quíntupla:

$$\lambda = (S, V, A, B, \pi)$$

### 1.1 Espacio de Estados Ocultos ($S$)
El conjunto de estados discretos no observables directamente que representan las fases neurofisiológicas del sueño es:

$$S = \{s_1, s_2, s_3, s_4\}$$

donde:
* $s_1$: **Despierto (Wake)**
* $s_2$: **Sueño Ligero (N1 + N2 / Light Sleep)**
* $s_3$: **Sueño Profundo (N3 / Slow Wave Sleep - SWS)**
* $s_4$: **Sueño de Movimientos Oculares Rápidos (REM)**

La secuencia temporal de estados latentes a lo largo de un horizonte de $T$ épocas discretas se denota como:

$$Q = (q_1, q_2, \dots, q_T), \quad q_t \in S, \quad T = 480 \text{ épocas}$$

*(En la implementación computacional, cada época equivale a 1 paso temporal / minuto simulado, totalizando 480 minutos u 8 horas de registro continuo nocturno; si se mapea al estándar clínico AASM de 30 segundos por época, equivale a 240 minutos o 4 horas).*

### 1.2 Alfabeto de Observaciones Discretas ($V$)
Cada observación en el instante $t$ corresponde a un patrón sinérgico multivariable compuesto por electroencefalograma (EEG), electrooculograma (EOG) y electromiograma de tono muscular mentoniano (EMG):

$$V = \{v_1, v_2, v_3, v_4, v_5\}$$

definidas de forma exhaustiva como:
1. $v_1$: `EEG_Alfa + EOG_Parpadeo + EMG_Alto` (característico de vigilia activa y relajada).
2. $v_2$: `EEG_Theta + EOG_Lento + EMG_Moderado` (transición a sueño ligero N1-N2).
3. $v_3$: `EEG_Delta + EOG_Nulo + EMG_Bajo` (sincronización de ondas lentas N3).
4. $v_4$: `EEG_Desincronizado + EOG_Rapido + EMG_Atonia` (sueño paradójico REM clásico).
5. $v_5$: `EEG_Huso_K + EOG_Nulo + EMG_Bajo` (complejos K y husos de sueño patognomónicos de N2).

La secuencia observada se denota como:

$$O = (o_1, o_2, \dots, o_T), \quad o_t \in V$$

---

## 2. Supuestos Probabilísticos Fundamentales

El modelo descansa sobre dos hipótesis matemáticas:

1. **Propiedad Markoviana de Primer Orden:**
   La probabilidad del estado actual depende únicamente del estado inmediatamente precedente, siendo condicionalmente independiente del historial pasado:
   $$P(q_t = s_j \mid q_{t-1} = s_i, q_{t-2}, \dots, q_1) = P(q_t = s_j \mid q_{t-1} = s_i) = A_{ij}$$

2. **Independencia Condicional de las Observaciones:**
   La observación generada en el instante $t$ depende exclusivamente del estado latente en dicho instante:
   $$P(o_t = v_k \mid q_1, \dots, q_T, o_1, \dots, o_{t-1}) = P(o_t = v_k \mid q_t = s_j) = B_{jk}$$

---

## 3. Parámetros del Modelo Base (HMM Base)

### 3.1 Distribución Inicial ($\pi$)
El vector de probabilidades de inicio $\pi = (\pi_i)_{i=1}^4$ modela al individuo acostándose en cama despierto:

$$\pi = \begin{bmatrix} 1.0 & 0.0 & 0.0 & 0.0 \end{bmatrix}, \quad \sum_{i=1}^4 \pi_i = 1.0$$

### 3.2 Matriz de Transición de Estados ($A$)
La matriz $A = [A_{ij}] \in \mathbb{R}^{4 \times 4}$, donde $A_{ij} = P(q_{t+1} = s_j \mid q_t = s_i)$, cumple $\sum_{j=1}^4 A_{ij} = 1.0$ para toda fila $i$:

$$A = \begin{bmatrix}
0.70 & 0.25 & 0.00 & 0.05 \\
0.10 & 0.60 & 0.20 & 0.10 \\
0.05 & 0.15 & 0.75 & 0.05 \\
0.10 & 0.15 & 0.05 & 0.70
\end{bmatrix}$$

### 3.3 Matriz de Emisión de Observaciones ($B$)
La matriz $B = [B_{jk}] \in \mathbb{R}^{4 \times 5}$, donde $B_{jk} = P(o_t = v_k \mid q_t = s_j)$, cumple $\sum_{k=1}^5 B_{jk} = 1.0$:

$$B = \begin{bmatrix}
0.70 & 0.10 & 0.00 & 0.10 & 0.10 \\
0.05 & 0.50 & 0.05 & 0.05 & 0.35 \\
0.00 & 0.05 & 0.80 & 0.00 & 0.15 \\
0.05 & 0.05 & 0.00 & 0.85 & 0.05
\end{bmatrix}$$

---

## 4. Distribución Geométrica de Permanencia en el HMM Estándar

En un HMM homogéneo de tiempo discreto, el tiempo de permanencia continua en un estado $s_i$, denotado por la variable aleatoria $D_i \in \{1, 2, 3, \dots\}$, sigue necesariamente una **distribución geométrica discreta**:

$$P(D_i = d) = (A_{ii})^{d-1} (1 - A_{ii}), \quad d \ge 1$$

### 4.1 Esperanza Matemática y Varianza
La media teórica de duración en épocas viene dada por:

$$\mathbb{E}[D_i] = \sum_{d=1}^{\infty} d \cdot P(D_i = d) = \frac{1}{1 - A_{ii}}$$

La varianza teórica de la duración es:

$$\mathrm{Var}(D_i) = \frac{A_{ii}}{(1 - A_{ii})^2}$$

### 4.2 Tiempos Medios Analíticos en el Modelo Base
Evaluando analíticamente según la resolución temporal de la época:

| Estado $s_i$ | Probabilidad $A_{ii}$ | $\mathbb{E}[D_i]$ (épocas) | $\mathbb{E}[D_i]$ ($\Delta t = 1.0\text{ min}$) | $\mathbb{E}[D_i]$ ($\Delta t = 0.5\text{ min}$) |
| :--- | :---: | :---: | :---: | :---: |
| **Despierto** | $0.70$ | $\frac{1}{1 - 0.70} = 3.333$ | $3.333\text{ min}$ | $1.667\text{ min}$ |
| **Sueño Ligero** | $0.60$ | $\frac{1}{1 - 0.60} = 2.500$ | $2.500\text{ min}$ | $1.250\text{ min}$ |
| **Sueño Profundo** | $0.75$ | $\frac{1}{1 - 0.75} = 4.000$ | $4.000\text{ min}$ | $2.000\text{ min}$ |
| **REM** | $0.70$ | $\frac{1}{1 - 0.70} = 3.333$ | $3.333\text{ min}$ | $1.667\text{ min}$ |

### 4.3 Propiedad de Falta de Memoria (*Memoryless Property*)
La distribución geométrica cumple:
$$P(D_i \ge d + k \mid D_i > k) = P(D_i \ge d)$$
Esta tasa de escape constante es fisiológicamente no realista, ya que la probabilidad biológica de despertar no es uniforme en cada época: un individuo que acaba de entrar en sueño profundo tiene una probabilidad ínfima de despertar durante los primeros 10 minutos debido a la presión homeostática de ondas lentas.

---

## 5. Formulación de Variantes Experimentales

### 5.1 HMM de Sueño Fragmentado
Esta variante simula una disrupción patológica (por ejemplo, síndrome de apnea obstructiva o insomnio psicofisiológico), incrementando la probabilidad de transición directa hacia el estado Despierto:
* $A_{2,1}: 0.10 \to 0.30$ ($+200\%$)
* $A_{3,1}: 0.05 \to 0.20$ ($+300\%$)
* $A_{4,1}: 0.10 \to 0.25$ ($+150\%$)

Para preservar el axioma estocástico $\sum_{j=1}^4 A_{ij} = 1.0$, las probabilidades restantes en cada fila se normalizan proporcionalmente:

$$A_{\text{frag}} = \begin{bmatrix}
0.7000 & 0.2500 & 0.0000 & 0.0500 \\
0.3000 & 0.4667 & 0.1556 & 0.0778 \\
0.2000 & 0.1263 & 0.6316 & 0.0421 \\
0.2500 & 0.1250 & 0.0417 & 0.5833
\end{bmatrix}$$

Las matrices $B$ y $\pi$ se mantienen idénticas para aislar formalmente el efecto de la dinámica de transición.

### 5.2 Modelo Oculto Semi-Markoviano (HSMM)
El HSMM desacopla la transición entre estados de la duración de permanencia:
1. **Cadena Embebida de Transición:**
   Se anulan los elementos de la diagonal principal ($A_{ii} = 0$), forzando transiciones entre estados distintos:
   $$A_{\text{embedded}} = \begin{bmatrix}
   0.0000 & 0.8333 & 0.0000 & 0.1667 \\
   0.2500 & 0.0000 & 0.5000 & 0.2500 \\
   0.2000 & 0.6000 & 0.0000 & 0.2000 \\
   0.3333 & 0.5000 & 0.1667 & 0.0000
   \end{bmatrix}$$

2. **Distribución Explícita de Duración:**
   Cada visita a un estado $s_i$ extrae una duración $d \sim p_i(d)$, modelada como uniforme discreta acotada $\mathcal{U}(d_{\min, i}, d_{\max, i})$:
   * Despierto: $d \sim \mathcal{U}(1, 8)$ épocas ($0.5$ a $4.0\text{ min}$). Media: $4.5\text{ épocas}$ ($2.25\text{ min}$).
   * Sueño Ligero: $d \sim \mathcal{U}(5, 25)$ épocas ($2.5$ a $12.5\text{ min}$). Media: $15.0\text{ épocas}$ ($7.5\text{ min}$).
   * Sueño Profundo: $d \sim \mathcal{U}(10, 35)$ épocas ($5.0$ a $17.5\text{ min}$). Media: $22.5\text{ épocas}$ ($11.25\text{ min}$).
   * REM: $d \sim \mathcal{U}(5, 30)$ épocas ($2.5$ a $15.0\text{ min}$). Media: $17.5\text{ épocas}$ ($8.75\text{ min}$).

La esperanza matemática y varianza de la distribución uniforme discreta son:
$$\mathbb{E}[D_i] = \frac{d_{\min, i} + d_{\max, i}}{2}, \quad \mathrm{Var}(D_i) = \frac{(d_{\max, i} - d_{\min, i} + 1)^2 - 1}{12}$$

---

## 6. Algoritmo de Decodificación Global (Log-Viterbi)

Para hallar la secuencia óptima de estados latentes $\hat{Q} = \arg\max_Q P(Q \mid O, \lambda)$ que maximiza la probabilidad a posteriori conjunta, se utiliza programación dinámica en espacio logarítmico para prevenir el subdesbordamiento aritmético (*numerical underflow*):

### 6.1 Inicialización ($t = 1$)
Para cada estado $j \in \{1, 2, 3, 4\}$:
$$\delta_1(j) = \ln \pi_j + \ln B_j(o_1)$$
$$\psi_1(j) = 0$$

### 6.2 Inducción Recursiva ($t = 2, 3, \dots, T$)
Para cada estado $j \in \{1, 2, 3, 4\}$:
$$\delta_t(j) = \max_{1 \le i \le 4} \left[ \delta_{t-1}(i) + \ln A_{ij} \right] + \ln B_j(o_t)$$
$$\psi_t(j) = \arg\max_{1 \le i \le 4} \left[ \delta_{t-1}(i) + \ln A_{ij} \right]$$

### 6.3 Terminación
$$\ln P^* = \max_{1 \le i \le 4} \delta_T(i)$$
$$\hat{q}_T = \arg\max_{1 \le i \le 4} \delta_T(i)$$

### 6.4 Reconstrucción Retrospectiva (*Backtracking*)
Para $t = T-1, T-2, \dots, 1$:
$$\hat{q}_t = \psi_{t+1}(\hat{q}_{t+1})$$

La complejidad temporal del algoritmo es $\mathcal{O}(T \cdot |S|^2)$ y la espacial es $\mathcal{O}(T \cdot |S|)$.

---

## 7. Decodificación Segmentaria en HSMM

En el HSMM, el estado latente se define por el par $(\text{estado}, \text{duración})$. La recursión de Viterbi segmentaria evalúa la probabilidad del mejor segmento que termina en el tiempo $t$ con estado $j$ y duración $d$:

$$\delta_t(j) = \max_{d_{\min, j} \le d \le \min(t, d_{\max, j})} \left\{ \max_{i \neq j} \left[ \delta_{t-d}(i) + \ln A_{ij}^{\text{emb}} \right] + \ln p_j(d) + \sum_{\tau=t-d+1}^t \ln B_j(o_\tau) \right\}$$

### 7.1 Optimización con Sumas de Prefijo
El término acumulado de emisión se precalcula en $\mathcal{O}(1)$ tiempo constante mediante una matriz de sumas de prefijo:
$$S_j(t) = \sum_{\tau=1}^t \ln B_j(o_\tau) \implies \sum_{\tau=t-d+1}^t \ln B_j(o_\tau) = S_j(t) - S_j(t-d)$$
reduciendo la complejidad temporal de $\mathcal{O}(T \cdot D_{\max}^2 \cdot |S|^2)$ a $\mathcal{O}(T \cdot D_{\max} \cdot |S|^2)$.

---

## 8. Formulación Inferencial Monte Carlo

Para cuantificar rigurosamente la incertidumbre estocástica de las simulaciones sintéticas frente a la variación en la trayectoria de números pseudoaleatorios, se implementa un diseño Monte Carlo con $M = 100$ réplicas independientes para cada modelo (semillas $s \in [1000, 1099]$).

Para cada métrica escalar $X \in \{\text{TST, SE, SOL, Despertares, Ciclos REM, Exactitud Viterbi}\}$:

1. **Media Muestral:**
   $$\bar{X} = \frac{1}{M} \sum_{m=1}^M X_m$$

2. **Varianza y Desviación Estándar Muestral:**
   $$s_X = \sqrt{\frac{1}{M - 1} \sum_{m=1}^M (X_m - \bar{X})^2}$$

3. **Error Estándar de la Media:**
   $$\mathrm{SE}(\bar{X}) = \frac{s_X}{\sqrt{M}}$$

4. **Intervalo de Confianza del 95% ($t$-Student con $\nu = 99$ grados de libertad):**
   $$\mathrm{IC}_{95\%}(\mu_X) = \left[ \bar{X} - t_{0.975, 99} \cdot \frac{s_X}{\sqrt{M}}, \quad \bar{X} + t_{0.975, 99} \cdot \frac{s_X}{\sqrt{M}} \right]$$
   donde el cuantil crítico bilateral es $t_{0.975, 99} \approx 1.9842$.
