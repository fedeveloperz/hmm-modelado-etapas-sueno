"""Simulación didáctica HMM de etapas del sueño. No es software clínico."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "resultados"
CSV_DIR = OUT / "csv"
FIG_DIR = OUT / "figuras"
OUT.mkdir(exist_ok=True)
CSV_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)
STATES = ["Despierto", "Sueño Ligero", "Sueño Profundo", "REM"]
OBS = ["Alpha", "Theta", "Delta", "Mov. oculares rápidos"]
COLORS = ["#2878B5", "#2CA25F", "#8E44AD", "#D62728"]
A = np.array([[.50,.40,.05,.05],
              [.10,.60,.20,.10],
              [.02,.28,.60,.10],
              [.20,.20,.00,.60]])
B = np.array([[.70,.20,.05,.05],
              [.15,.65,.15,.05],
              [.02,.13,.80,.05],
              [.10,.10,.10,.70]])
PI = np.array([.50,.30,.10,.10])
N = 480
SEED = 42

def validate():
    assert A.shape == (4,4) and B.shape == (4,4)
    assert np.allclose(A.sum(axis=1), 1) and np.allclose(B.sum(axis=1), 1)
    assert np.all(A >= 0) and np.all(B >= 0)
    assert np.isclose(PI.sum(), 1)

def simulate(rng):
    states = np.zeros(N, dtype=int)
    obs = np.zeros(N, dtype=int)
    states[0] = rng.choice(4, p=PI)
    obs[0] = rng.choice(4, p=B[states[0]])
    for t in range(1,N):
        states[t] = rng.choice(4, p=A[states[t-1]])
        obs[t] = rng.choice(4, p=B[states[t]])
    return states, obs

def viterbi(observations):
    # Logaritmos para evitar underflow
    logA = np.log(np.maximum(A, 1e-300))
    logB = np.log(np.maximum(B, 1e-300))
    logPI = np.log(np.maximum(PI, 1e-300))
    T = len(observations)
    delta = np.full((T,4), -np.inf)
    back = np.zeros((T,4), dtype=int)
    delta[0] = logPI + logB[:, observations[0]]
    for t in range(1,T):
        for j in range(4):
            scores = delta[t-1] + logA[:,j]
            back[t,j] = np.argmax(scores)
            delta[t,j] = scores[back[t,j]] + logB[j, observations[t]]
    path = np.zeros(T,dtype=int)
    path[-1] = np.argmax(delta[-1])
    for t in range(T-2,-1,-1):
        path[t] = back[t+1,path[t+1]]
    return path

def count_cycles(states):
    # Criterio operativo aproximado: cada entrada a REM tras haber pasado por
    # sueño no-REM (Ligero o Profundo) cuenta como un ciclo simulado.
    cycles, seen_nrem = 0, False
    for s in states:
        if s in (1,2): seen_nrem = True
        if s == 3 and seen_nrem:
            cycles += 1
            seen_nrem = False
    return cycles

def main():
    validate()
    rng = np.random.default_rng(SEED)
    latent, observations = simulate(rng)
    inferred = viterbi(observations)
    minutes_asleep = int(np.sum(latent != 0))
    sleep_eff = 100 * minutes_asleep / N
    latency = next((i for i,s in enumerate(latent) if s != 0), N)
    accuracy = 100 * np.mean(latent == inferred)
    rows=[]
    for i,name in enumerate(STATES):
        mins=int(np.sum(latent==i))
        rows.append({"Etapa":name,"Minutos simulados":mins,"Porcentaje":100*mins/N})
    metrics=pd.DataFrame(rows)
    print("=== INFORME DESCRIPTIVO (SIMULACIÓN; NO CLÍNICO) ===")
    print(f"Eficiencia simulada: {sleep_eff:.2f}%")
    print(f"Latencia simulada: {latency} min")
    print(f"Ciclos según criterio operativo: {count_cycles(latent)}")
    print(f"Despertares (entradas a Despierto después de dormir): {sum(latent[t]==0 and latent[t-1]!=0 for t in range(1,N))}")
    print(f"Coincidencia latente/Viterbi: {accuracy:.2f}% (solo posible porque conocemos estados simulados)")
    print(metrics.to_string(index=False))
    metrics.to_csv(OUT/"metricas_etapas.csv", index=False)
    metrics.to_csv(CSV_DIR/"metricas_etapas.csv", index=False)
    
    seq_df = pd.DataFrame({"minuto": np.arange(N), "estado_latente": latent, "observacion": observations, "estado_viterbi": inferred})
    seq_df.to_csv(OUT/"secuencia_simulada.csv", index=False)
    seq_df.to_csv(CSV_DIR/"secuencia_simulada.csv", index=False)

    # Hipnograma: escalones para estados latentes e inferidos
    fig,ax=plt.subplots(figsize=(14,4))
    ax.step(np.arange(N),latent,where="post",label="Estado latente simulado",lw=1.8)
    ax.step(np.arange(N),inferred,where="post",label="Viterbi",lw=1.2,alpha=.75)
    ax.set_yticks(range(4),STATES); ax.set_xlabel("Minuto"); ax.set_title("Hipnograma simulado: latente vs Viterbi")
    ax.grid(alpha=.25); ax.legend(); fig.tight_layout()
    fig.savefig(OUT/"hipnograma.png",dpi=160); fig.savefig(FIG_DIR/"hipnograma.png",dpi=160); plt.close(fig)

    # Observación categórica como señal esquemática (no EEG físico)
    fig,ax=plt.subplots(figsize=(14,3))
    ax.step(np.arange(N),observations,where="mid",color="#444")
    ax.set_yticks(range(4),OBS); ax.set_xlabel("Minuto")
    ax.set_title("Observaciones categóricas simuladas (no trazado EEG real)")
    ax.grid(alpha=.25); fig.tight_layout()
    fig.savefig(OUT/"observaciones.png",dpi=160); fig.savefig(FIG_DIR/"observaciones.png",dpi=160); plt.close(fig)

    fig,ax=plt.subplots(figsize=(6,5)); im=ax.imshow(A,cmap="Blues",vmin=0,vmax=1)
    ax.set_xticks(range(4),STATES,rotation=35,ha="right"); ax.set_yticks(range(4),STATES)
    ax.set_xlabel("Estado siguiente"); ax.set_ylabel("Estado actual"); ax.set_title("Matriz A (transición)")
    for r in range(4):
        for c in range(4): ax.text(c,r,f"{A[r,c]:.2f}",ha="center",va="center",color="black")
    fig.colorbar(im,ax=ax); fig.tight_layout()
    fig.savefig(OUT/"matriz_transicion.png",dpi=160); fig.savefig(FIG_DIR/"matriz_transicion.png",dpi=160); plt.close(fig)
    print(f"\nArchivos guardados en: {CSV_DIR} y {FIG_DIR}")

if __name__=="__main__":
    main()
