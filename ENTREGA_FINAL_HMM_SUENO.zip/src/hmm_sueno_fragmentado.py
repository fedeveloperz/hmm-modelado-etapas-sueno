"""Experimento de sueño fragmentado mediante HMM modificado.

Este script conserva intactos los parámetros originales del caso base
y crea la variante experimental HMM_FRAGMENTADO para estudiar el efecto
de una mayor probabilidad de despertar desde las fases de sueño.
No es software clínico ni representa un paciente real.
"""

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "resultados" / "modifica"
CSV_DIR = ROOT / "resultados" / "csv"
FIG_DIR = ROOT / "resultados" / "figuras"
OUT.mkdir(parents=True, exist_ok=True)
CSV_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

STATES = ["Despierto", "Sueño Ligero", "Sueño Profundo", "REM"]
OBS = ["Alpha", "Theta", "Delta", "Mov. oculares rápidos"]
COLORS = ["#2878B5", "#2CA25F", "#8E44AD", "#D62728"]
N = 480
SEED = 42

# 1. Parámetros del modelo original (base)
A_ORIG = np.array([
    [0.50, 0.40, 0.05, 0.05],
    [0.10, 0.60, 0.20, 0.10],
    [0.02, 0.28, 0.60, 0.10],
    [0.20, 0.20, 0.00, 0.60]
])

B = np.array([
    [0.70, 0.20, 0.05, 0.05],
    [0.15, 0.65, 0.15, 0.05],
    [0.02, 0.13, 0.80, 0.05],
    [0.10, 0.10, 0.10, 0.70]
])

PI = np.array([0.50, 0.30, 0.10, 0.10])

# 2. Construcción proporcional de A_FRAGMENTADO
# Se incrementa la probabilidad de despertar hacia Despierto (columna 0):
# - Ligero: de 0.10 a 0.30 (factor de reescalado restante: 0.70 / 0.90)
# - Profundo: de 0.02 a 0.15 (factor de reescalado restante: 0.85 / 0.98)
# - REM: de 0.20 a 0.40 (factor de reescalado restante: 0.60 / 0.80)
# Despierto se conserva igual [0.50, 0.40, 0.05, 0.05].

A_FRAG = np.copy(A_ORIG)
TARGET_WAKE = [0.50, 0.30, 0.15, 0.40]

for i in range(1, 4):
    orig_wake = A_ORIG[i, 0]
    new_wake = TARGET_WAKE[i]
    scale = (1.0 - new_wake) / (1.0 - orig_wake)
    A_FRAG[i, 0] = new_wake
    for j in range(1, 4):
        A_FRAG[i, j] = A_ORIG[i, j] * scale

def validate_matrices():
    for name, mat in [("A_ORIG", A_ORIG), ("A_FRAG", A_FRAG), ("B", B)]:
        assert mat.shape == (4, 4), f"{name} debe ser 4x4"
        assert np.all(mat >= 0), f"{name} contiene valores negativos"
        assert np.allclose(mat.sum(axis=1), 1.0), f"Filas de {name} no suman 1.0"
    assert np.isclose(PI.sum(), 1.0) and np.all(PI >= 0)

def simulate(rng, A_mat, B_mat, PI_vec):
    states = np.zeros(N, dtype=int)
    obs = np.zeros(N, dtype=int)
    states[0] = rng.choice(4, p=PI_vec)
    obs[0] = rng.choice(4, p=B_mat[states[0]])
    for t in range(1, N):
        states[t] = rng.choice(4, p=A_mat[states[t-1]])
        obs[t] = rng.choice(4, p=B_mat[states[t]])
    return states, obs

def viterbi(observations, A_mat, B_mat, PI_vec):
    logA = np.log(np.maximum(A_mat, 1e-300))
    logB = np.log(np.maximum(B_mat, 1e-300))
    logPI = np.log(np.maximum(PI_vec, 1e-300))
    T = len(observations)
    delta = np.full((T, 4), -np.inf)
    back = np.zeros((T, 4), dtype=int)
    
    delta[0] = logPI + logB[:, observations[0]]
    for t in range(1, T):
        for j in range(4):
            scores = delta[t-1] + logA[:, j]
            back[t, j] = np.argmax(scores)
            delta[t, j] = scores[back[t, j]] + logB[j, observations[t]]
            
    path = np.zeros(T, dtype=int)
    path[-1] = np.argmax(delta[-1])
    for t in range(T-2, -1, -1):
        path[t] = back[t+1, path[t+1]]
    return path

def count_cycles(states):
    cycles, seen_nrem = 0, False
    for s in states:
        if s in (1, 2):
            seen_nrem = True
        if s == 3 and seen_nrem:
            cycles += 1
            seen_nrem = False
    return cycles

def count_awakenings(states):
    return sum(states[t] == 0 and states[t-1] != 0 for t in range(1, N))

def get_bouts(states):
    bouts = []
    curr = states[0]
    dur = 1
    for s in states[1:]:
        if s == curr:
            dur += 1
        else:
            bouts.append((curr, dur))
            curr = s
            dur = 1
    bouts.append((curr, dur))
    return bouts

def compute_metrics(latent, inferred):
    tst = int(np.sum(latent != 0))
    eff = 100.0 * tst / N
    latency = next((i for i, s in enumerate(latent) if s != 0), N)
    awakenings = count_awakenings(latent)
    cycles = count_cycles(latent)
    acc = 100.0 * np.mean(latent == inferred)
    
    stage_mins = [int(np.sum(latent == i)) for i in range(4)]
    stage_pcts = [100.0 * m / N for m in stage_mins]
    
    bouts = get_bouts(latent)
    bdf = pd.DataFrame(bouts, columns=["Estado", "Duracion"])
    mean_dur = [bdf[bdf["Estado"] == i]["Duracion"].mean() if len(bdf[bdf["Estado"] == i]) > 0 else 0.0 for i in range(4)]
    
    return {
        "TST_min": tst,
        "Eficiencia_pct": eff,
        "Latencia_min": latency,
        "Despertares": awakenings,
        "Ciclos_REM": cycles,
        "Exactitud_Viterbi_pct": acc,
        "Min_Despierto": stage_mins[0],
        "Pct_Despierto": stage_pcts[0],
        "Min_Ligero": stage_mins[1],
        "Pct_Ligero": stage_pcts[1],
        "Min_Profundo": stage_mins[2],
        "Pct_Profundo": stage_pcts[2],
        "Min_REM": stage_mins[3],
        "Pct_REM": stage_pcts[3],
        "DurMedia_Despierto": mean_dur[0],
        "DurMedia_Ligero": mean_dur[1],
        "DurMedia_Profundo": mean_dur[2],
        "DurMedia_REM": mean_dur[3]
    }

def main():
    validate_matrices()
    
    # Simulación Modelo Original
    rng_orig = np.random.default_rng(SEED)
    lat_orig, obs_orig = simulate(rng_orig, A_ORIG, B, PI)
    inf_orig = viterbi(obs_orig, A_ORIG, B, PI)
    met_orig = compute_metrics(lat_orig, inf_orig)
    
    # Simulación Modelo Fragmentado
    rng_frag = np.random.default_rng(SEED)
    lat_frag, obs_frag = simulate(rng_frag, A_FRAG, B, PI)
    inf_frag = viterbi(obs_frag, A_FRAG, B, PI)
    met_frag = compute_metrics(lat_frag, inf_frag)
    
    # Tabla comparativa de diferencias
    comp_rows = []
    metric_labels = [
        ("Tiempo Total de Sueño (TST)", "TST_min", "min"),
        ("Eficiencia del Sueño", "Eficiencia_pct", "%"),
        ("Latencia al Inicio del Sueño", "Latencia_min", "min"),
        ("Despertares tras dormir", "Despertares", "eventos"),
        ("Ciclos REM computados", "Ciclos_REM", "ciclos"),
        ("Exactitud Latente vs Viterbi", "Exactitud_Viterbi_pct", "%"),
        ("Tiempo Despierto", "Min_Despierto", "min"),
        ("Porcentaje Despierto", "Pct_Despierto", "%"),
        ("Tiempo Sueño Ligero", "Min_Ligero", "min"),
        ("Porcentaje Sueño Ligero", "Pct_Ligero", "%"),
        ("Tiempo Sueño Profundo", "Min_Profundo", "min"),
        ("Porcentaje Sueño Profundo", "Pct_Profundo", "%"),
        ("Tiempo Fase REM", "Min_REM", "min"),
        ("Porcentaje Fase REM", "Pct_REM", "%"),
        ("Duración media episodio Despierto", "DurMedia_Despierto", "min"),
        ("Duración media episodio Ligero", "DurMedia_Ligero", "min"),
        ("Duración media episodio Profundo", "DurMedia_Profundo", "min"),
        ("Duración media episodio REM", "DurMedia_REM", "min"),
    ]
    
    for label, key, unit in metric_labels:
        val_orig = met_orig[key]
        val_frag = met_frag[key]
        diff = val_frag - val_orig
        comp_rows.append({
            "Metrica": label,
            "Unidad": unit,
            "Modelo_Base (Original)": round(val_orig, 2),
            "Modelo_Fragmentado": round(val_frag, 2),
            "Diferencia (Frag - Base)": round(diff, 2)
        })
    comp_df = pd.DataFrame(comp_rows)
    print("=== TABLA COMPARATIVA EXPERIMENTAL ===")
    print(comp_df.to_string(index=False))
    comp_df.to_csv(OUT / "comparacion_metricas.csv", index=False)
    comp_df.to_csv(CSV_DIR / "comparacion_metricas.csv", index=False)
    
    # CSV detallado de secuencia fragmentada
    df_sec_frag = pd.DataFrame({
        "minuto": np.arange(N),
        "latente_base": lat_orig,
        "viterbi_base": inf_orig,
        "latente_fragmentado": lat_frag,
        "observacion_fragmentado": obs_frag,
        "viterbi_fragmentado": inf_frag
    })
    df_sec_frag.to_csv(OUT / "secuencia_fragmentada.csv", index=False)
    df_sec_frag.to_csv(CSV_DIR / "secuencia_fragmentada.csv", index=False)
    
    # CSV de etapas fragmentado
    stage_rows = []
    for i, name in enumerate(STATES):
        mins = int(np.sum(lat_frag == i))
        stage_rows.append({
            "Etapa": name,
            "Minutos_Simulados": mins,
            "Porcentaje": round(100.0 * mins / N, 2)
        })
    pd.DataFrame(stage_rows).to_csv(OUT / "metricas_etapas_fragmentado.csv", index=False)
    pd.DataFrame(stage_rows).to_csv(CSV_DIR / "metricas_etapas_fragmentado.csv", index=False)
    
    # FIGURA 1: Hipnogramas comparativos apilados
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 6), sharex=True)
    
    ax1.step(np.arange(N), lat_orig, where="post", color="#1F77B4", lw=1.6, label="Latente Base")
    ax1.step(np.arange(N), inf_orig, where="post", color="#AEC7E8", lw=1.0, alpha=0.85, label="Viterbi Base")
    ax1.set_yticks(range(4))
    ax1.set_yticklabels(STATES)
    ax1.set_title(f"Modelo Base (Eficiencia: {met_orig['Eficiencia_pct']:.1f}%, Despertares: {met_orig['Despertares']}, Ciclos: {met_orig['Ciclos_REM']})")
    ax1.grid(alpha=0.25)
    ax1.legend(loc="upper right")
    
    ax2.step(np.arange(N), lat_frag, where="post", color="#D62728", lw=1.6, label="Latente Fragmentado")
    ax2.step(np.arange(N), inf_frag, where="post", color="#FF9896", lw=1.0, alpha=0.85, label="Viterbi Fragmentado")
    ax2.set_yticks(range(4))
    ax2.set_yticklabels(STATES)
    ax2.set_xlabel("Minuto (de 0 a 480)")
    ax2.set_title(f"Modelo HMM_FRAGMENTADO (Eficiencia: {met_frag['Eficiencia_pct']:.1f}%, Despertares: {met_frag['Despertares']}, Ciclos: {met_frag['Ciclos_REM']})")
    ax2.grid(alpha=0.25)
    ax2.legend(loc="upper right")
    
    fig.tight_layout()
    fig.savefig(OUT / "hipnograma_comparativo.png", dpi=160)
    fig.savefig(FIG_DIR / "hipnograma_comparativo.png", dpi=160)
    plt.close(fig)
    
    # FIGURA 2: Matriz de transición fragmentada (heatmap)
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(A_FRAG, cmap="Reds", vmin=0, vmax=1)
    ax.set_xticks(range(4))
    ax.set_xticklabels(STATES, rotation=35, ha="right")
    ax.set_yticks(range(4))
    ax.set_yticklabels(STATES)
    ax.set_xlabel("Estado siguiente")
    ax.set_ylabel("Estado actual")
    ax.set_title("Matriz A_FRAGMENTADO (Mayor probabilidad a Despierto)")
    for r in range(4):
        for c in range(4):
            ax.text(c, r, f"{A_FRAG[r, c]:.2f}", ha="center", va="center", color="black" if A_FRAG[r,c] < 0.6 else "white")
    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    fig.savefig(OUT / "matriz_transicion_fragmentada.png", dpi=160)
    fig.savefig(FIG_DIR / "matriz_transicion_fragmentada.png", dpi=160)
    plt.close(fig)
    
    # FIGURA 3: Comparación de tiempo por etapas (barras agrupadas)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    x = np.arange(4)
    width = 0.35
    mins_orig = [met_orig["Min_Despierto"], met_orig["Min_Ligero"], met_orig["Min_Profundo"], met_orig["Min_REM"]]
    mins_frag = [met_frag["Min_Despierto"], met_frag["Min_Ligero"], met_frag["Min_Profundo"], met_frag["Min_REM"]]
    
    ax.bar(x - width/2, mins_orig, width, label="Modelo Base", color="#1F77B4")
    ax.bar(x + width/2, mins_frag, width, label="Modelo Fragmentado", color="#D62728")
    ax.set_xticks(x)
    ax.set_xticklabels(STATES)
    ax.set_ylabel("Minutos simulados")
    ax.set_title("Comparación de distribución temporal por etapa")
    for i in range(4):
        ax.text(i - width/2, mins_orig[i] + 3, f"{mins_orig[i]}m", ha="center", fontsize=9)
        ax.text(i + width/2, mins_frag[i] + 3, f"{mins_frag[i]}m", ha="center", fontsize=9)
    ax.set_ylim(0, max(max(mins_orig), max(mins_frag)) + 25)
    ax.legend()
    ax.grid(alpha=0.2, axis="y")
    fig.tight_layout()
    fig.savefig(OUT / "comparacion_etapas.png", dpi=160)
    fig.savefig(FIG_DIR / "comparacion_etapas.png", dpi=160)
    plt.close(fig)
    
    print(f"\nResultados experimentales guardados en: {OUT}")

if __name__ == "__main__":
    main()
