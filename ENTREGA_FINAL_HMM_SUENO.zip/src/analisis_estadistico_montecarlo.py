"""Análisis estadístico multirréplica (Monte Carlo) para los tres modelos HMM de sueño.

Este script ejecuta M = 100 simulaciones independientes con semillas reproducibles
(seeds 1000 a 1099) para los tres modelos:
1. HMM Base (Original)
2. HMM Fragmentado
3. HMM Semi-Markov (HSMM)

Calcula Media, Desviación Estándar, Mínimo, Máximo e Intervalos de Confianza al 95%
para las métricas clave de la macroestructura y decodificación del sueño.
Genera tablas CSV y la figura comparativa de intervalos de confianza.
No es software clínico ni representa registros de pacientes reales.
"""

import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Configuración de rutas
ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT / "src"))

from hmm_sueno import (
    A as A_BASE,
    B,
    PI,
    simulate as sim_base,
    viterbi as vit_base,
    count_cycles as cyc_base
)
from hmm_sueno_fragmentado import (
    A_FRAG,
    simulate as sim_frag,
    viterbi as vit_frag
)
from hmm_semimarkov import (
    A_EMBEDDED,
    DUR_RANGES,
    simulate_hsmm,
    viterbi_hsmm,
    count_cycles as cyc_hsmm
)

OUT_RES = ROOT / "resultados"
CSV_DIR = OUT_RES / "csv"
FIG_DIR = OUT_RES / "figuras"
OUT_RES.mkdir(parents=True, exist_ok=True)
CSV_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

N = 480
M_REPLICAS = 100
START_SEED = 1000
T_CRIT_99 = 1.984217  # t_{0.975, 99} para intervalo de confianza al 95%

def count_awakenings(states):
    return int(sum(states[t] == 0 and states[t-1] != 0 for t in range(1, len(states))))

def compute_run_metrics(latent, inferred, cycle_fn):
    tst = int(np.sum(latent != 0))
    eff = 100.0 * tst / N
    latency = next((i for i, s in enumerate(latent) if s != 0), N)
    awakenings = count_awakenings(latent)
    cycles = int(cycle_fn(latent))
    acc = 100.0 * np.mean(latent == inferred)
    
    mins_wake = int(np.sum(latent == 0))
    mins_light = int(np.sum(latent == 1))
    mins_deep = int(np.sum(latent == 2))
    mins_rem = int(np.sum(latent == 3))
    
    pct_wake = 100.0 * mins_wake / N
    pct_light = 100.0 * mins_light / N
    pct_deep = 100.0 * mins_deep / N
    pct_rem = 100.0 * mins_rem / N
    
    return {
        "TST_min": tst,
        "Eficiencia_pct": eff,
        "Latencia_min": latency,
        "Despertares": awakenings,
        "Ciclos_REM": cycles,
        "Exactitud_Viterbi_pct": acc,
        "Min_Despierto": mins_wake,
        "Pct_Despierto": pct_wake,
        "Min_Ligero": mins_light,
        "Pct_Ligero": pct_light,
        "Min_Profundo": mins_deep,
        "Pct_Profundo": pct_deep,
        "Min_REM": mins_rem,
        "Pct_REM": pct_rem
    }

def run_monte_carlo():
    print(f"Iniciando análisis Monte Carlo: M = {M_REPLICAS} réplicas por modelo...")
    all_runs = []
    
    for rep in range(M_REPLICAS):
        seed = START_SEED + rep
        
        # 1. HMM Base
        rng_b = np.random.default_rng(seed)
        lat_b, obs_b = sim_base(rng_b)
        inf_b = vit_base(obs_b)
        met_b = compute_run_metrics(lat_b, inf_b, cyc_base)
        met_b["Modelo"] = "HMM Base"
        met_b["Replica"] = rep + 1
        met_b["Semilla"] = seed
        all_runs.append(met_b)
        
        # 2. HMM Fragmentado
        rng_f = np.random.default_rng(seed)
        lat_f, obs_f = sim_frag(rng_f, A_FRAG, B, PI)
        inf_f = vit_frag(obs_f, A_FRAG, B, PI)
        met_f = compute_run_metrics(lat_f, inf_f, cyc_base)
        met_f["Modelo"] = "HMM Fragmentado"
        met_f["Replica"] = rep + 1
        met_f["Semilla"] = seed
        all_runs.append(met_f)
        
        # 3. HMM Semi-Markov
        rng_s = np.random.default_rng(seed)
        lat_s, obs_s = simulate_hsmm(rng_s)
        inf_s = viterbi_hsmm(obs_s)
        met_s = compute_run_metrics(lat_s, inf_s, cyc_hsmm)
        met_s["Modelo"] = "HMM Semi-Markov"
        met_s["Replica"] = rep + 1
        met_s["Semilla"] = seed
        all_runs.append(met_s)
        
    df_runs = pd.DataFrame(all_runs)
    raw_path = OUT_RES / "corridas_montecarlo_tres_modelos.csv"
    df_runs.to_csv(raw_path, index=False)
    df_runs.to_csv(CSV_DIR / "corridas_montecarlo_tres_modelos.csv", index=False)
    print(f"Corridas individuales guardadas en: {CSV_DIR / 'corridas_montecarlo_tres_modelos.csv'}")
    
    # Calcular estadísticas descriptivas e inferenciales
    metric_cols = [
        ("TST_min", "Tiempo Total de Sueño (TST)", "min"),
        ("Eficiencia_pct", "Eficiencia del Sueño", "%"),
        ("Latencia_min", "Latencia al Inicio del Sueño", "min"),
        ("Despertares", "Despertares tras dormir", "eventos"),
        ("Ciclos_REM", "Ciclos de Sueño REM", "ciclos"),
        ("Exactitud_Viterbi_pct", "Exactitud de Decodificación Viterbi", "%"),
        ("Pct_Despierto", "Porcentaje en Vigilia (W)", "%"),
        ("Pct_Ligero", "Porcentaje en Sueño Ligero (N1+N2)", "%"),
        ("Pct_Profundo", "Porcentaje en Sueño Profundo (N3)", "%"),
        ("Pct_REM", "Porcentaje en Sueño REM (R)", "%")
    ]
    
    models = ["HMM Base", "HMM Fragmentado", "HMM Semi-Markov"]
    summary_rows = []
    
    for col_key, metric_name, unit in metric_cols:
        row = {
            "Metrica": metric_name,
            "Unidad": unit
        }
        for mod in models:
            sub = df_runs[df_runs["Modelo"] == mod][col_key].values
            mean_val = float(np.mean(sub))
            std_val = float(np.std(sub, ddof=1))
            min_val = float(np.min(sub))
            max_val = float(np.max(sub))
            se_val = std_val / np.sqrt(M_REPLICAS)
            ci_margin = T_CRIT_99 * se_val
            ci_low = mean_val - ci_margin
            ci_high = mean_val + ci_margin
            
            prefix = mod.replace(" ", "_")
            row[f"{prefix}_Media"] = round(mean_val, 2)
            row[f"{prefix}_Std"] = round(std_val, 2)
            row[f"{prefix}_Min"] = round(min_val, 2)
            row[f"{prefix}_Max"] = round(max_val, 2)
            row[f"{prefix}_IC95_Inf"] = round(ci_low, 2)
            row[f"{prefix}_IC95_Sup"] = round(ci_high, 2)
            row[f"{prefix}_IC95_Str"] = f"[{ci_low:.2f}, {ci_high:.2f}]"
            
        summary_rows.append(row)
        
    df_summary = pd.DataFrame(summary_rows)
    sum_path = OUT_RES / "estadisticas_montecarlo_tres_modelos.csv"
    df_summary.to_csv(sum_path, index=False)
    df_summary.to_csv(CSV_DIR / "estadisticas_montecarlo_tres_modelos.csv", index=False)
    print(f"Resumen estadístico guardado en: {CSV_DIR / 'estadisticas_montecarlo_tres_modelos.csv'}")
    
    # Imprimir tabla legible
    print("\n" + "="*80)
    print(f"RESULTADOS MONTE CARLO (M = {M_REPLICAS} réplicas por modelo)")
    print("="*80)
    for r in summary_rows:
        m = r['Metrica']
        u = r['Unidad']
        print(f"\n* {m} ({u}):")
        for mod in models:
            p = mod.replace(' ', '_')
            print(f"  - {mod:16s}: Media = {r[p+'_Media']:6.2f} ± {r[p+'_Std']:5.2f} | Rango = [{r[p+'_Min']:5.2f}, {r[p+'_Max']:5.2f}] | IC 95% = {r[p+'_IC95_Str']}")
            
    # Generar Figura 10: Comparación de Intervalos de Confianza (95%)
    fig, axes = plt.subplots(2, 2, figsize=(13, 10))
    colors = ["#2878B5", "#D95F02", "#2CA25F"]
    x_pos = np.arange(len(models))
    
    # 1. Eficiencia del sueño
    ax1 = axes[0, 0]
    eff_means = [df_summary.loc[df_summary["Metrica"]=="Eficiencia del Sueño", f"{m.replace(' ','_')}_Media"].values[0] for m in models]
    eff_stds = [df_summary.loc[df_summary["Metrica"]=="Eficiencia del Sueño", f"{m.replace(' ','_')}_Std"].values[0] for m in models]
    eff_cis = [T_CRIT_99 * s / np.sqrt(M_REPLICAS) for s in eff_stds]
    bars1 = ax1.bar(x_pos, eff_means, yerr=eff_cis, capsize=6, color=colors, alpha=0.85, edgecolor="black", linewidth=1.2)
    ax1.set_xticks(x_pos)
    ax1.set_xticklabels(models, fontweight="bold")
    ax1.set_ylabel("Eficiencia del Sueño (%)", fontsize=11)
    ax1.set_title("A) Eficiencia del Sueño (Media ± IC 95%)", fontsize=12, fontweight="bold")
    ax1.set_ylim(0, 100)
    ax1.axhline(85, color="gray", linestyle="--", alpha=0.7, label="Umbral fisiológico normal (85%)")
    ax1.grid(axis="y", linestyle=":", alpha=0.6)
    ax1.legend(loc="lower left", fontsize=9)
    for bar, val in zip(bars1, eff_means):
        ax1.text(bar.get_x() + bar.get_width()/2.0, val + 3.0, f"{val:.1f}%", ha="center", va="bottom", fontweight="bold", fontsize=10)
        
    # 2. Despertares
    ax2 = axes[0, 1]
    w_means = [df_summary.loc[df_summary["Metrica"]=="Despertares tras dormir", f"{m.replace(' ','_')}_Media"].values[0] for m in models]
    w_stds = [df_summary.loc[df_summary["Metrica"]=="Despertares tras dormir", f"{m.replace(' ','_')}_Std"].values[0] for m in models]
    w_cis = [T_CRIT_99 * s / np.sqrt(M_REPLICAS) for s in w_stds]
    bars2 = ax2.bar(x_pos, w_means, yerr=w_cis, capsize=6, color=colors, alpha=0.85, edgecolor="black", linewidth=1.2)
    ax2.set_xticks(x_pos)
    ax2.set_xticklabels(models, fontweight="bold")
    ax2.set_ylabel("Número de Despertares (eventos)", fontsize=11)
    ax2.set_title("B) Despertares tras Dormir (Media ± IC 95%)", fontsize=12, fontweight="bold")
    ax2.grid(axis="y", linestyle=":", alpha=0.6)
    for bar, val in zip(bars2, w_means):
        ax2.text(bar.get_x() + bar.get_width()/2.0, val + 2.5, f"{val:.1f}", ha="center", va="bottom", fontweight="bold", fontsize=10)
        
    # 3. Ciclos REM
    ax3 = axes[1, 0]
    cyc_means = [df_summary.loc[df_summary["Metrica"]=="Ciclos de Sueño REM", f"{m.replace(' ','_')}_Media"].values[0] for m in models]
    cyc_stds = [df_summary.loc[df_summary["Metrica"]=="Ciclos de Sueño REM", f"{m.replace(' ','_')}_Std"].values[0] for m in models]
    cyc_cis = [T_CRIT_99 * s / np.sqrt(M_REPLICAS) for s in cyc_stds]
    bars3 = ax3.bar(x_pos, cyc_means, yerr=cyc_cis, capsize=6, color=colors, alpha=0.85, edgecolor="black", linewidth=1.2)
    ax3.set_xticks(x_pos)
    ax3.set_xticklabels(models, fontweight="bold")
    ax3.set_ylabel("Ciclos Estimados (número)", fontsize=11)
    ax3.set_title("C) Conteo de Ciclos REM (Media ± IC 95%)", fontsize=12, fontweight="bold")
    ax3.axhspan(4, 6, color="green", alpha=0.15, label="Rango fisiológico humano (4–6 ciclos)")
    ax3.grid(axis="y", linestyle=":", alpha=0.6)
    ax3.legend(loc="upper right", fontsize=9)
    for bar, val in zip(bars3, cyc_means):
        ax3.text(bar.get_x() + bar.get_width()/2.0, val + 1.0, f"{val:.1f}", ha="center", va="bottom", fontweight="bold", fontsize=10)
        
    # 4. Exactitud de Decodificación Viterbi
    ax4 = axes[1, 1]
    acc_means = [df_summary.loc[df_summary["Metrica"]=="Exactitud de Decodificación Viterbi", f"{m.replace(' ','_')}_Media"].values[0] for m in models]
    acc_stds = [df_summary.loc[df_summary["Metrica"]=="Exactitud de Decodificación Viterbi", f"{m.replace(' ','_')}_Std"].values[0] for m in models]
    acc_cis = [T_CRIT_99 * s / np.sqrt(M_REPLICAS) for s in acc_stds]
    bars4 = ax4.bar(x_pos, acc_means, yerr=acc_cis, capsize=6, color=colors, alpha=0.85, edgecolor="black", linewidth=1.2)
    ax4.set_xticks(x_pos)
    ax4.set_xticklabels(models, fontweight="bold")
    ax4.set_ylabel("Exactitud de Inferencia (%)", fontsize=11)
    ax4.set_title("D) Exactitud de Viterbi (Media ± IC 95%)", fontsize=12, fontweight="bold")
    ax4.set_ylim(50, 100)
    ax4.grid(axis="y", linestyle=":", alpha=0.6)
    for bar, val in zip(bars4, acc_means):
        ax4.text(bar.get_x() + bar.get_width()/2.0, val + 1.2, f"{val:.1f}%", ha="center", va="bottom", fontweight="bold", fontsize=10)
        
    fig.suptitle("Comparación Inferencial Monte Carlo (M = 100 réplicas por modelo)\nBarras de error representan Intervalos de Confianza al 95%", 
                 fontsize=14, fontweight="bold", y=0.99)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig_path = OUT_RES / "comparacion_intervalos_confianza.png"
    fig.savefig(fig_path, dpi=180)
    fig.savefig(FIG_DIR / "comparacion_intervalos_confianza.png", dpi=180)
    plt.close(fig)
    print(f"\nFigura de intervalos de confianza guardada en: {FIG_DIR / 'comparacion_intervalos_confianza.png'}")

if __name__ == "__main__":
    run_monte_carlo()
