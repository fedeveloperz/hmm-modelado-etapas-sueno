# -*- coding: utf-8 -*-
"""Organización y estandarización de directorios para repositorio GitHub."""

import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "resultados"
CSV_DIR = RES / "csv"
FIG_DIR = RES / "figuras"

CSV_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

# 1. Mapeo de archivos CSV hacia resultados/csv/
csv_sources = [
    RES / "metricas_etapas.csv",
    RES / "secuencia_simulada.csv",
    RES / "estadisticas_montecarlo_tres_modelos.csv",
    RES / "corridas_montecarlo_tres_modelos.csv",
    RES / "modifica" / "comparacion_metricas.csv",
    RES / "modifica" / "metricas_etapas_fragmentado.csv",
    RES / "modifica" / "secuencia_fragmentada.csv",
    RES / "crea" / "comparacion_tres_modelos.csv",
    RES / "crea" / "metricas_etapas_semimarkov.csv",
    RES / "crea" / "secuencia_semimarkov.csv"
]

print("=== Copiando CSVs a resultados/csv/ ===")
for src in csv_sources:
    if src.exists():
        dst = CSV_DIR / src.name
        shutil.copy2(src, dst)
        print(f"CSV: {src.relative_to(ROOT)} -> {dst.relative_to(ROOT)}")
    else:
        print(f"ADVERTENCIA: No encontrado {src}")

# 2. Mapeo de figuras PNG hacia resultados/figuras/
fig_sources = [
    RES / "hipnograma.png",
    RES / "matriz_transicion.png",
    RES / "observaciones.png",
    RES / "comparacion_intervalos_confianza.png",
    RES / "modifica" / "hipnograma_comparativo.png",
    RES / "modifica" / "comparacion_etapas.png",
    RES / "modifica" / "matriz_transicion_fragmentada.png",
    RES / "crea" / "hipnograma_semimarkov.png",
    RES / "crea" / "hipnograma_tres_modelos.png",
    RES / "crea" / "distribucion_etapas_tres_modelos.png"
]

print("\n=== Copiando Figuras a resultados/figuras/ ===")
for src in fig_sources:
    if src.exists():
        dst = FIG_DIR / src.name
        shutil.copy2(src, dst)
        print(f"Figura: {src.relative_to(ROOT)} -> {dst.relative_to(ROOT)}")
    else:
        print(f"ADVERTENCIA: No encontrado {src}")

print(f"\nOrganización completada:")
print(f"Total CSVs en resultados/csv/: {len(list(CSV_DIR.glob('*.csv')))}")
print(f"Total Figuras en resultados/figuras/: {len(list(FIG_DIR.glob('*.png')))}")
