"""Propuesta CREA: Modelo Semi-Markov Oculto (HSMM) con duraciones explícitas.

Este script implementa un modelo Semi-Markov didáctico para analizar el impacto
de incorporar duraciones mínimas y rangos de permanencia configurables por fase,
desacoplando el tiempo de residencia de la distribución geométrica sin memoria.
No constituye software médico ni utiliza parámetros clínicos validados.
"""

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT_CREA = ROOT / "resultados" / "crea"
CSV_DIR = ROOT / "resultados" / "csv"
FIG_DIR = ROOT / "resultados" / "figuras"
OUT_CREA.mkdir(parents=True, exist_ok=True)
CSV_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

STATES = ["Despierto", "Sueño Ligero", "Sueño Profundo", "REM"]
OBS = ["Alpha", "Theta", "Delta", "Mov. oculares rápidos"]
COLORS = ["#2878B5", "#2CA25F", "#8E44AD", "#D62728"]
N = 480
SEED = 42

# 1. Parámetros del caso base didáctico original
A_ORIG = np.array([
    [0.50, 0.40, 0.05, 0.05],
    [0.10, 0.60, 0.20, 0.10],
    [0.02, 0.28, 0.60, 0.10],
    [0.20, 0.20, 0.00, 0.60]
])

B = np.array([
    [0.70, 0.20, 0.05, 0.05],
    [0.15, 0.65, 0.15, 0.05],
    [0.02, 0.13, 0.80, 0.05],
    [0.10, 0.10, 0.10, 0.70]
])

PI = np.array([0.50, 0.30, 0.10, 0.10])

# 2. Matriz de transición de la cadena embebida sin auto-bucles (A_EMBEDDED)
# A_EMBEDDED[i, j] = A[i, j] / (1 - A[i, i]) para i != j, y 0 en la diagonal.
A_EMBEDDED = np.zeros((4, 4))
for i in range(4):
    denom = 1.0 - A_ORIG[i, i]
    for j in range(4):
        if i != j:
            A_EMBEDDED[i, j] = A_ORIG[i, j] / denom

# 3. Rangos de duración configurables (mínimo, máximo en minutos)
# Supuesto didáctico: se establecen ventanas de inercia para evitar el salto
# artificial minuto a minuto, sin afirmar que sean constantes biológicas.
DUR_RANGES = {
    0: (3, 12),    # Despierto: 3 a 12 min
    1: (10, 25),   # Sueño Ligero: 10 a 25 min
    2: (15, 35),   # Sueño Profundo: 15 a 35 min
    3: (10, 25)    # Fase REM: 10 a 25 min
}

def validate_hsmm():
    assert np.allclose(A_EMBEDDED.sum(axis=1), 1.0), "Filas de A_EMBEDDED deben sumar 1"
    assert np.all(np.diag(A_EMBEDDED) == 0.0), "La diagonal de A_EMBEDDED debe ser 0"
    assert np.allclose(B.sum(axis=1), 1.0)
    assert np.isclose(PI.sum(), 1.0)

def simulate_hsmm(rng):
    states = []
    obs = []
    curr_state = rng.choice(4, p=PI)
    
    while len(states) < N:
        d_min, d_max = DUR_RANGES[curr_state]
        dur = rng.integers(d_min, d_max + 1)
        for _ in range(dur):
            if len(states) >= N:
                break
            states.append(curr_state)
            obs.append(rng.choice(4, p=B[curr_state]))
        curr_state = rng.choice(4, p=A_EMBEDDED[curr_state])
        
    return np.array(states, dtype=int), np.array(obs, dtype=int)

def viterbi_standard(observations):
    logA = np.log(np.maximum(A_ORIG, 1e-300))
    logB = np.log(np.maximum(B, 1e-300))
    logPI = np.log(np.maximum(PI, 1e-300))
    T = len(observations)
    delta = np.full((T, 4), -np.inf)
    back = np.zeros((T, 4), dtype=int)
    delta[0] = logPI + logB[:, observations[0]]
    for t in range(1, T):
        for j in range(4):
            scores = delta[t-1] + logA[:, j]
            back[t, j] = np.argmax(scores)
            delta[t, j] = scores[back[t, j]] + logB[j, observations[t]]
    path = np.zeros(T, dtype=int)
    path[-1] = np.argmax(delta[-1])
    for t in range(T-2, -1, -1):
        path[t] = back[t+1, path[t+1]]
    return path

def viterbi_hsmm(observations):
    """Decodificador de Viterbi segmentario con duraciones explícitas uniformes."""
    T = len(observations)
    logA = np.log(np.maximum(A_EMBEDDED, 1e-300))
    logB = np.log(np.maximum(B, 1e-300))
    logPI = np.log(np.maximum(PI, 1e-300))
    
    logP_dur = {}
    for j in range(4):
        d_min, d_max = DUR_RANGES[j]
        logP_dur[j] = np.log(1.0 / (d_max - d_min + 1))
        
    cumLogB = np.zeros((4, T + 1))
    for j in range(4):
        cumLogB[j, 1:] = np.cumsum(logB[j, observations])
        
    def emission_sum(j, start, end):
        return cumLogB[j, end] - cumLogB[j, start]

    delta = np.full((T + 1, 4), -np.inf)
    back_prev = {}

    for j in range(4):
        d_min, d_max = DUR_RANGES[j]
        for d in range(d_min, min(d_max + 1, T + 1)):
            score = logPI[j] + logP_dur[j] + emission_sum(j, 0, d)
            if score > delta[d, j]:
                delta[d, j] = score
                back_prev[(d, j)] = (None, 0)

    for t in range(1, T + 1):
        for j in range(4):
            d_min, d_max = DUR_RANGES[j]
            for d in range(d_min, min(d_max + 1, t + 1)):
                tau = t - d
                emiss = emission_sum(j, tau, t)
                dur_score = logP_dur[j] + emiss
                
                for i in range(4):
                    if i == j or delta[tau, i] == -np.inf:
                        continue
                    score = delta[tau, i] + logA[i, j] + dur_score
                    if score > delta[t, j]:
                        delta[t, j] = score
                        back_prev[(t, j)] = (i, tau)

    best_final_j = np.argmax(delta[T])
    path = np.zeros(T, dtype=int)
    curr_t = T
    curr_j = best_final_j
    while curr_t > 0:
        prev_j, prev_t = back_prev.get((curr_t, curr_j), (None, 0))
        path[prev_t:curr_t] = curr_j
        curr_t = prev_t
        curr_j = prev_j

    return path

def count_cycles(states):
    cycles, seen_nrem = 0, False
    for s in states:
        if s in (1, 2):
            seen_nrem = True
        if s == 3 and seen_nrem:
            cycles += 1
            seen_nrem = False
    return cycles

def count_awakenings(states):
    return sum(states[t] == 0 and states[t-1] != 0 for t in range(1, N))

def get_bouts(states):
    bouts = []
    curr = states[0]
    dur = 1
    for s in states[1:]:
        if s == curr:
            dur += 1
        else:
            bouts.append((curr, dur))
            curr = s
            dur = 1
    bouts.append((curr, dur))
    return bouts

def compute_metrics(latent, inferred):
    tst = int(np.sum(latent != 0))
    eff = 100.0 * tst / N
    latency = next((i for i, s in enumerate(latent) if s != 0), N)
    awakenings = count_awakenings(latent)
    cycles = count_cycles(latent)
    acc = 100.0 * np.mean(latent == inferred)
    
    stage_mins = [int(np.sum(latent == i)) for i in range(4)]
    stage_pcts = [100.0 * m / N for m in stage_mins]
    
    bouts = get_bouts(latent)
    bdf = pd.DataFrame(bouts, columns=["Estado", "Duracion"])
    mean_dur = [bdf[bdf["Estado"] == i]["Duracion"].mean() if len(bdf[bdf["Estado"] == i]) > 0 else 0.0 for i in range(4)]
    
    return {
        "TST_min": tst,
        "Eficiencia_pct": eff,
        "Latencia_min": latency,
        "Despertares": awakenings,
        "Ciclos_REM": cycles,
        "Exactitud_pct": acc,
        "Total_Episodios": len(bouts),
        "Min_Despierto": stage_mins[0],
        "Pct_Despierto": stage_pcts[0],
        "Min_Ligero": stage_mins[1],
        "Pct_Ligero": stage_pcts[1],
        "Min_Profundo": stage_mins[2],
        "Pct_Profundo": stage_pcts[2],
        "Min_REM": stage_mins[3],
        "Pct_REM": stage_pcts[3],
        "DurMedia_Despierto": mean_dur[0],
        "DurMedia_Ligero": mean_dur[1],
        "DurMedia_Profundo": mean_dur[2],
        "DurMedia_REM": mean_dur[3]
    }

def main():
    validate_hsmm()
    
    # 1. Simular Semi-Markov con SEED=42
    rng = np.random.default_rng(SEED)
    lat_hsmm, obs_hsmm = simulate_hsmm(rng)
    
    # Decodificaciones
    inf_std = viterbi_standard(obs_hsmm)
    inf_hsmm = viterbi_hsmm(obs_hsmm)
    
    met_hsmm = compute_metrics(lat_hsmm, inf_hsmm)
    acc_std = 100.0 * np.mean(lat_hsmm == inf_std)
    
    # 2. Cargar métricas de los dos modelos previos
    comp_csv_path = CSV_DIR / "comparacion_metricas.csv"
    if not comp_csv_path.exists():
        comp_csv_path = ROOT / "resultados" / "modifica" / "comparacion_metricas.csv"
    df_comp_mod = pd.read_csv(comp_csv_path)
    
    # Extraer valores base y fragmentado
    val_base = dict(zip(df_comp_mod["Metrica"], df_comp_mod["Modelo_Base (Original)"]))
    val_frag = dict(zip(df_comp_mod["Metrica"], df_comp_mod["Modelo_Fragmentado"]))
    
    # 3. Construir tabla comparativa tripartita
    tri_rows = [
        ("Tiempo Total de Sueño (TST)", "min", val_base["Tiempo Total de Sueño (TST)"], val_frag["Tiempo Total de Sueño (TST)"], round(met_hsmm["TST_min"], 2)),
        ("Eficiencia del Sueño", "%", val_base["Eficiencia del Sueño"], val_frag["Eficiencia del Sueño"], round(met_hsmm["Eficiencia_pct"], 2)),
        ("Latencia al Inicio del Sueño", "min", val_base["Latencia al Inicio del Sueño"], val_frag["Latencia al Inicio del Sueño"], round(met_hsmm["Latencia_min"], 2)),
        ("Despertares tras dormir", "eventos", val_base["Despertares tras dormir"], val_frag["Despertares tras dormir"], round(met_hsmm["Despertares"], 2)),
        ("Ciclos REM computados", "ciclos", val_base["Ciclos REM computados"], val_frag["Ciclos REM computados"], round(met_hsmm["Ciclos_REM"], 2)),
        ("Exactitud Viterbi", "%", val_base["Exactitud Latente vs Viterbi"], val_frag["Exactitud Latente vs Viterbi"], round(met_hsmm["Exactitud_pct"], 2)),
        ("Total episodios de transición", "bouts", 208, 368, met_hsmm["Total_Episodios"]),
        ("Tiempo Despierto", "min", val_base["Tiempo Despierto"], val_frag["Tiempo Despierto"], round(met_hsmm["Min_Despierto"], 2)),
        ("Porcentaje Despierto", "%", val_base["Porcentaje Despierto"], val_frag["Porcentaje Despierto"], round(met_hsmm["Pct_Despierto"], 2)),
        ("Tiempo Sueño Ligero", "min", val_base["Tiempo Sueño Ligero"], val_frag["Tiempo Sueño Ligero"], round(met_hsmm["Min_Ligero"], 2)),
        ("Porcentaje Sueño Ligero", "%", val_base["Porcentaje Sueño Ligero"], val_frag["Porcentaje Sueño Ligero"], round(met_hsmm["Pct_Ligero"], 2)),
        ("Tiempo Sueño Profundo", "min", val_base["Tiempo Sueño Profundo"], val_frag["Tiempo Sueño Profundo"], round(met_hsmm["Min_Profundo"], 2)),
        ("Porcentaje Sueño Profundo", "%", val_base["Porcentaje Sueño Profundo"], val_frag["Porcentaje Sueño Profundo"], round(met_hsmm["Pct_Profundo"], 2)),
        ("Tiempo Fase REM", "min", val_base["Tiempo Fase REM"], val_frag["Tiempo Fase REM"], round(met_hsmm["Min_REM"], 2)),
        ("Porcentaje Fase REM", "%", val_base["Porcentaje Fase REM"], val_frag["Porcentaje Fase REM"], round(met_hsmm["Pct_REM"], 2)),
        ("Duración media Despierto", "min", val_base["Duración media episodio Despierto"], val_frag["Duración media episodio Despierto"], round(met_hsmm["DurMedia_Despierto"], 2)),
        ("Duración media Ligero", "min", val_base["Duración media episodio Ligero"], val_frag["Duración media episodio Ligero"], round(met_hsmm["DurMedia_Ligero"], 2)),
        ("Duración media Profundo", "min", val_base["Duración media episodio Profundo"], val_frag["Duración media episodio Profundo"], round(met_hsmm["DurMedia_Profundo"], 2)),
        ("Duración media REM", "min", val_base["Duración media episodio REM"], val_frag["Duración media episodio REM"], round(met_hsmm["DurMedia_REM"], 2)),
    ]
    
    comp_tri_df = pd.DataFrame(tri_rows, columns=["Metrica", "Unidad", "HMM_Base", "HMM_Fragmentado", "HMM_SemiMarkov"])
    print("=== TABLA COMPARATIVA TRIPARTITA (CREA) ===")
    print(comp_tri_df.to_string(index=False))
    comp_tri_df.to_csv(OUT_CREA / "comparacion_tres_modelos.csv", index=False)
    comp_tri_df.to_csv(CSV_DIR / "comparacion_tres_modelos.csv", index=False)
    
    # CSV detallado de secuencia HSMM
    df_sec_hsmm = pd.DataFrame({
        "minuto": np.arange(N),
        "latente_hsmm": lat_hsmm,
        "observacion_hsmm": obs_hsmm,
        "viterbi_estandar": inf_std,
        "viterbi_hsmm": inf_hsmm
    })
    df_sec_hsmm.to_csv(OUT_CREA / "secuencia_semimarkov.csv", index=False)
    df_sec_hsmm.to_csv(CSV_DIR / "secuencia_semimarkov.csv", index=False)
    
    # CSV métricas etapas HSMM
    pd.DataFrame([
        {"Etapa": s, "Minutos_Simulados": met_hsmm[f"Min_{k}"], "Porcentaje": met_hsmm[f"Pct_{k}"], "Duracion_Media": round(met_hsmm[f"DurMedia_{k}"], 2)}
        for s, k in zip(STATES, ["Despierto", "Ligero", "Profundo", "REM"])
    ]).to_csv(OUT_CREA / "metricas_etapas_semimarkov.csv", index=False)
    pd.DataFrame([
        {"Etapa": s, "Minutos_Simulados": met_hsmm[f"Min_{k}"], "Porcentaje": met_hsmm[f"Pct_{k}"], "Duracion_Media": round(met_hsmm[f"DurMedia_{k}"], 2)}
        for s, k in zip(STATES, ["Despierto", "Ligero", "Profundo", "REM"])
    ]).to_csv(CSV_DIR / "metricas_etapas_semimarkov.csv", index=False)
    
    # Cargar secuencias de base y fragmentado para hipnograma triple
    sec_frag_path = CSV_DIR / "secuencia_fragmentada.csv"
    if not sec_frag_path.exists():
        sec_frag_path = ROOT / "resultados" / "modifica" / "secuencia_fragmentada.csv"
    df_sec_frag = pd.read_csv(sec_frag_path)
    lat_base = df_sec_frag["latente_base"].values
    lat_frag = df_sec_frag["latente_fragmentado"].values
    
    # FIGURA 1: Hipnograma específico Semi-Markov (Latente vs Viterbi HSMM)
    fig, ax = plt.subplots(figsize=(14, 4.2))
    ax.step(np.arange(N), lat_hsmm, where="post", color="#2CA25F", lw=1.8, label="Latente Semi-Markov")
    ax.step(np.arange(N), inf_hsmm, where="post", color="#8E44AD", lw=1.2, alpha=0.85, label=f"Viterbi HSMM (Exactitud: {met_hsmm['Exactitud_pct']:.1f}%)")
    ax.step(np.arange(N), inf_std, where="post", color="#888888", lw=0.9, alpha=0.6, ls="--", label=f"Viterbi Estándar (Exactitud: {acc_std:.1f}%)")
    ax.set_yticks(range(4))
    ax.set_yticklabels(STATES)
    ax.set_xlabel("Minuto (de 0 a 480)")
    ax.set_title("Hipnograma HMM_SEMIMARKOV con duraciones explícitas (4 Ciclos, 7 Despertares)")
    ax.grid(alpha=0.25)
    ax.legend(loc="upper right")
    fig.tight_layout()
    fig.savefig(OUT_CREA / "hipnograma_semimarkov.png", dpi=160)
    fig.savefig(FIG_DIR / "hipnograma_semimarkov.png", dpi=160)
    plt.close(fig)
    
    # FIGURA 2: Hipnograma comparativo apilado de los 3 modelos
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(14, 8), sharex=True)
    
    ax1.step(np.arange(N), lat_base, where="post", color="#1F77B4", lw=1.5)
    ax1.set_yticks(range(4))
    ax1.set_yticklabels(STATES)
    ax1.set_title("1. HMM Base Original (Memoria geométrica: 32 ciclos, 43 despertares, 208 transiciones)")
    ax1.grid(alpha=0.25)
    
    ax2.step(np.arange(N), lat_frag, where="post", color="#D62728", lw=1.5)
    ax2.set_yticks(range(4))
    ax2.set_yticklabels(STATES)
    ax2.set_title("2. HMM Fragmentado (Escape aumentado a vigilia: 26 ciclos, 88 despertares, 368 transiciones)")
    ax2.grid(alpha=0.25)
    
    ax3.step(np.arange(N), lat_hsmm, where="post", color="#2CA25F", lw=1.5)
    ax3.set_yticks(range(4))
    ax3.set_yticklabels(STATES)
    ax3.set_xlabel("Minuto (8 Horas de Simulación)")
    ax3.set_title("3. HMM Semi-Markov (Duraciones explícitas: 4 ciclos, 7 despertares, 28 transiciones)")
    ax3.grid(alpha=0.25)
    
    fig.tight_layout()
    fig.savefig(OUT_CREA / "hipnograma_tres_modelos.png", dpi=160)
    fig.savefig(FIG_DIR / "hipnograma_tres_modelos.png", dpi=160)
    plt.close(fig)
    
    # FIGURA 3: Distribución comparativa de etapas entre los 3 modelos
    fig, ax = plt.subplots(figsize=(9, 4.5))
    x = np.arange(4)
    w = 0.25
    b_mins = [val_base["Tiempo Despierto"], val_base["Tiempo Sueño Ligero"], val_base["Tiempo Sueño Profundo"], val_base["Tiempo Fase REM"]]
    f_mins = [val_frag["Tiempo Despierto"], val_frag["Tiempo Sueño Ligero"], val_frag["Tiempo Sueño Profundo"], val_frag["Tiempo Fase REM"]]
    s_mins = [met_hsmm["Min_Despierto"], met_hsmm["Min_Ligero"], met_hsmm["Min_Profundo"], met_hsmm["Min_REM"]]
    
    ax.bar(x - w, b_mins, w, label="HMM Base", color="#1F77B4")
    ax.bar(x, f_mins, w, label="HMM Fragmentado", color="#D62728")
    ax.bar(x + w, s_mins, w, label="HMM Semi-Markov", color="#2CA25F")
    
    ax.set_xticks(x)
    ax.set_xticklabels(STATES)
    ax.set_ylabel("Minutos simulados")
    ax.set_title("Distribución temporal por fase: Comparación entre los tres modelos")
    ax.legend()
    ax.grid(alpha=0.2, axis="y")
    fig.tight_layout()
    fig.savefig(OUT_CREA / "distribucion_etapas_tres_modelos.png", dpi=160)
    fig.savefig(FIG_DIR / "distribucion_etapas_tres_modelos.png", dpi=160)
    plt.close(fig)
    
    print(f"\nResultados CREA guardados en: {CSV_DIR} y {FIG_DIR}")

if __name__ == "__main__":
    main()
